from flask import Flask, render_template, request, jsonify
import pickle
import numpy as np

app = Flask(__name__)

# Load trained ML model (make sure this is the correct .pkl)
with open("restaurant_rating_model.pkl", "rb") as file:
    model = pickle.load(file)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/predict", methods=["POST"])
def predict():
    data = request.json
    
    try:
        # Convert to correct types and match feature order used during training
        features = np.array([[
            int(data["price"]),            # Price range
            int(data["table_booking"]),    # Has Table booking
            int(data["online_delivery"]),  # Has Online delivery
            int(data["votes"]),            # Votes
            int(data["distance"])          # Distance_Category
        ]])
        
        # Predict rating
        prediction = model.predict(features)[0]

        return jsonify({
            "rating": round(float(prediction), 2)
        })
    
    except Exception as e:
        # Send error back to frontend instead of undefined
        return jsonify({
            "rating": None,
            "error": str(e)
        })

if __name__ == "__main__":
    app.run(debug=True)
