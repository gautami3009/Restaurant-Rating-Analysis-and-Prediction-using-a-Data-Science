const priceSlider = document.getElementById("price");
const priceVal = document.getElementById("priceVal");

priceSlider.oninput = () => {
    priceVal.innerText = priceSlider.value;
};

function predict() {
    const resultDiv = document.getElementById("result");
    resultDiv.innerText = "Processing...";

    // Prepare JSON data to send to Flask
    const data = {
        price: Number(priceSlider.value),
        table_booking: Number(document.getElementById("table_booking").value),
        online_delivery: Number(document.getElementById("online_delivery").value),
        votes: Number(document.getElementById("votes").value),
        distance: Number(document.getElementById("distance").value) // 0 = Near, 1 = Far
    };

    // Send to Flask backend
    fetch("/predict", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(res => res.json())
    .then(result => {
        if (result.rating !== undefined && result.rating !== null) {
            resultDiv.innerText = `⭐ Predicted Rating: ${result.rating}`;
        } else if (result.error) {
            resultDiv.innerText = `Error: ${result.error}`;
        } else {
            resultDiv.innerText = "Prediction failed ❌";
        }
    })
    .catch(err => {
        resultDiv.innerText = "Error connecting to server ❌";
        console.error(err);
    });
}
